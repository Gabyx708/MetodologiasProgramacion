﻿using System;
using System.Collections.Generic;
using System.Text;
using MetodologíasDeProgramaciónI;

namespace TP01
{
    class AlumnoAdapter : Student
    {
        Alumno alumno;

        public AlumnoAdapter(Alumno a)
        {
            alumno = a;
        }

        public string getName()
        {
            return alumno.getNombre();
        }

        public int yourAnswerIs(int question)
        {
            return alumno.responderPregunta();
        }
        public void setScore(int score)
        {
             alumno.setCalificacion(score);
        }
        public string showResult()
        {
            return getName()+" note: "+alumno.getCalificacion();
        }
        public  bool equals(Student student)
        {
            return alumno.sosIgual((Alumno)student);
        }
        public bool lessThan(Student student)
        {
            return alumno.sosMenor((Alumno)student);
        }
        public bool greaterThan(Student student)
        {
            return alumno.sosMayor((Alumno)student);
        }
    }

    class AlumnoMuyEstAdapter : Student
    {
        AlumMuyEstud alumno;

        public AlumnoMuyEstAdapter(AlumMuyEstud a)
        {
            alumno = a;
        }

        public string getName()
        {
            return alumno.getNombre();
        }

        public int yourAnswerIs(int question)
        {
            return alumno.responderPregunta();
        }
        public void setScore(int score)
        {
            alumno.setCalificacion(score);
        }
        public string showResult()
        {
            return "x";
        }
        public bool equals(Student student)
        {
            return alumno.sosIgual((AlumMuyEstud)student);
        }
        public bool lessThan(Student student)
        {
            return alumno.sosMenor((AlumMuyEstud)student);
        }
        public bool greaterThan(Student student)
        {
            return alumno.sosMayor((AlumMuyEstud)student);
        }
    }
}
